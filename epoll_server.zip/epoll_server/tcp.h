#ifndef EPOLL_SERVER_TCP_H
#define EPOLL_SERVER_TCP_H

#include "epollfd.h"
#include "epollinstance.h"


class Tcp : public EpollFd {
public:
    Tcp(int port, EpollInstance &e);
    void handleEvent(uint32_t events);
};

#endif //EPOLL_SERVER_TCP_H
