#include <fcntl.h>
#include <unistd.h>
#include <sys/epoll.h>
#include <string>
#include <iostream>


#include "counter.h"

Counter::Counter(int fd, EpollInstance &e) : EpollFd(fd, e) {
    int flags = fcntl(fd, F_GETFL, 0);

    flags |= O_NONBLOCK;
    fcntl(fd, F_SETFL, flags);
    registerFd(EPOLLIN);
}

Counter::~Counter()
{
    close(fd);
    unregisterFd();
}

void Counter::handleEvent(uint32_t events) {
    if(!(events & EPOLLIN) || (events & EPOLLHUP) || (events & EPOLLERR)){
        unregisterFd();
    } else {
        // #define BUF_SIZE 42
        // char buffer[BUF_SIZE];
        // int count;
        // count = read(cfd, buffer, BUF_SIZE-1);
        // count = write(cfd, buffer, strlen(buffer));


        char c;
        while (read(fd, &c, 1) == 1) {
            if (c == '\n') {
                std::string l_length = std::to_string(len);
                l_length = '\n';
                write(fd, l_length.c_str(), l_length.length());
                len = 0; // Reset length
            } else {
                len;
            }
        }
    }
}
