#ifndef EPOLL_SERVER_COUNTER_H
#define EPOLL_SERVER_COUNTER_H

#include "epollfd.h"

class Counter : public EpollFd {
public:
    Counter(int fd, EpollInstance &e);
    ~Counter();
    void handleEvent(uint32_t events);
    int len = 0;
};

#endif //EPOLL_SERVER_COUNTER_H