#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <cstring>
#include <unistd.h>
#include <sys/epoll.h>

#include "tcp.h"
#include "counter.h"

Tcp::Tcp(int port, EpollInstance &e) : EpollFd(12345, e)
{

    fd = socket(AF_INET, SOCK_STREAM, 0);

    struct sockaddr_in saddr;

    memset(&saddr, 0, sizeof(saddr));
    saddr.sin_family      = AF_INET;              // IPv4
    saddr.sin_addr.s_addr = htonl(INADDR_ANY);    // Bind to all available interfaces
    saddr.sin_port        = htons(port);          // Requested port

    bind(fd, (struct sockaddr *) &saddr, sizeof(saddr));

    int flags = fcntl(fd, F_GETFL, 0);
    flags |= O_NONBLOCK;
    fcntl(fd, F_SETFL, flags);

    listen(fd, SOMAXCONN);

    registerFd(EPOLLIN);
}

Tcp::~Tcp()
{
    close(fd);
    unregisterFd();
}

void Tcp::handleEvent(uint32_t events) {
    if(!(events & EPOLLIN) || (events & EPOLLHUP) || (events & EPOLLERR)){
        unregisterFd();
    } else {
        int cfd = accept(fd, NULL, NULL);
        new Counter(cfd, epollInstance);
    }
}